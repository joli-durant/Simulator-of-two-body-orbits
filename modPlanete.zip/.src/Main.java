import java.util.ArrayList;
import java.awt.*;

public class Main {
    public static void main(String[] args) {

        ArrayList<AstreCentrale> astresCtr = new ArrayList<AstreCentrale>();
        ArrayList<AstreAutour> astresAtr = new ArrayList<AstreAutour>();

        // constuire une list des astres centrals
        //(couleur, taille de rayon sur l'écran, masse_kg, nom)
        AstreCentrale soleil = new AstreCentrale(Color.YELLOW, 40, 1.98847e30, "soleil");
        astresCtr.add(soleil);
        AstreCentrale mercureCtr = new AstreCentrale(Color.RED, 40, 3.3011e23, "mercure");
        astresCtr.add(mercureCtr);
        AstreCentrale venusCtr = new AstreCentrale(Color.MAGENTA, 40, 4.868e24, "venus");
        astresCtr.add(venusCtr);
        AstreCentrale terreCtr = new AstreCentrale(Color.blue, 40, 5.9722e24, "terre");
        astresCtr.add(terreCtr);
        AstreCentrale marsCtr = new AstreCentrale(Color.orange, 40, 0.642e24, "mars");
        astresCtr.add(marsCtr);
        AstreCentrale jupiterCtr = new AstreCentrale(new Color(201, 188, 137), 40, 1.898e27, "jupiter");
        astresCtr.add(jupiterCtr);
        AstreCentrale saturneCtr = new AstreCentrale(new Color(135, 125, 96), 40, 5.683e26, "saturne");
        astresCtr.add(saturneCtr);
        AstreCentrale uranusCtr = new AstreCentrale(new Color(137, 164, 187), 40, 8.681e25, "uranus");
        astresCtr.add(uranusCtr);
        AstreCentrale neptuneCtr = new AstreCentrale(new Color(83, 93, 134), 40, 1.024e26, "neptune");
        astresCtr.add(neptuneCtr);

        // constuire une list des astres autours
        //(couleur, l'astre central, taille de rayon sur l'écran, masse_kg, nom, distance_AU, vitesse_m/s)
        AstreAutour mercureAtr = new AstreAutour(Color.RED, soleil, 7, 3.3011e23, "mercure", 0.387, 47.87e3);
        astresAtr.add(mercureAtr);

        AstreAutour venusAtr = new AstreAutour(Color.MAGENTA, soleil, 10, 4.868e24, "venus", 0.723, 35.02e3);
        astresAtr.add(venusAtr);

        AstreAutour terreAtr = new AstreAutour(Color.blue, soleil, 13, 5.9722e24, "terre", 1, 29.8e3);
        astresAtr.add(terreAtr);

        AstreAutour marsAtr = new AstreAutour(Color.orange, soleil, 7, 0.642e24, "mars", 1.5, 24.1e3);
        astresAtr.add(marsAtr);

        AstreAutour jupiterAtr = new AstreAutour(new Color(201, 188, 137), soleil, 30, 1.898e27, "jupiter", 5.2,
                13.06e3);
        astresAtr.add(jupiterAtr);

        AstreAutour saturneAtr = new AstreAutour(new Color(135, 125, 96), soleil, 28, 5.683e26, "saturne", 9.54,
                9.69e3);
        astresAtr.add(saturneAtr);

        AstreAutour uranusAtr = new AstreAutour(new Color(137, 164, 187), soleil, 20, 8.681e25, "uranus", 19.2, 6.81e3);
        astresAtr.add(uranusAtr);

        AstreAutour neptuneAtr = new AstreAutour(new Color(83, 93, 134), soleil, 20, 1.024e26, "neptune", 30.6, 5.43e3);
        astresAtr.add(neptuneAtr);

        AstreAutour lune = new AstreAutour(new Color(255, 255, 255), terreCtr, 20, 7.347e22, "lune", 0.00257, 1022);
        astresAtr.add(lune);

        SelectionAstres sa = new SelectionAstres(astresCtr, astresAtr);
    }
}
