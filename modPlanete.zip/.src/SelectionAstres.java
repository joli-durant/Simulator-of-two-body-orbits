import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;

public class SelectionAstres extends JFrame implements ActionListener {

    JPanel panneauGlobal;
    JLabel plCentral;
    JComboBox SelectCtr;
    JLabel plAutour;
    JComboBox SelectAtr;
    JButton solarSystem;
    JButton definissez;
    JButton start;
    JLabel Help;


    private SimulationObt fenetreSimu;
    private SimSysSolar windowSolar;

    private ArrayList<AstreCentrale> astresCtr;
    private ArrayList<AstreAutour> astresAtr;

    public AstreCentrale simAstCtrl;
    public AstreAutour simAstAtr;

    public SelectionAstres(ArrayList<AstreCentrale> astresCtr, ArrayList<AstreAutour> astresAtr) {
        this.astresCtr = astresCtr;
        this.astresAtr = astresAtr;

        this.setTitle("Simulation Orbitale");
        this.setSize(800, 500);
        this.setForeground(Color.BLACK);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        plCentral = new JLabel("Astre central");
        Font font1 = new Font("Arial Black", Font.PLAIN, 24);
        plCentral.setFont(font1);
        plCentral.setSize(400, 50);
        plCentral.setLocation(100, 100);
        plCentral.setForeground(Color.white);

        // String[] StrAstreCtr = { "non-selected", "soleil", "terre" };
        // remplir la liste des astres centrals
        String[] StrAstreCtr = new String[10];
        StrAstreCtr[0] = "non-selected";
        for (AstreCentrale c : astresCtr) {
            StrAstreCtr[astresCtr.indexOf(c) + 1] = c.name;
        }
        SelectCtr = new JComboBox(StrAstreCtr);

        SelectCtr.setBounds(100, 200, 150, 40);

        plAutour = new JLabel("Satellite");
        plAutour.setFont(font1);
        plAutour.setSize(400, 50);
        plAutour.setLocation(500, 100);
        plAutour.setForeground(Color.white);

        // remplir la liste des astres autours
        String[] StrAstreAtr = new String[10];
        StrAstreAtr[0] = "non-selected";
        for (AstreAutour a : astresAtr) {
            StrAstreAtr[astresAtr.indexOf(a) + 1] = a.name;
        }
        SelectAtr = new JComboBox(StrAstreAtr);
        SelectAtr.setBounds(500, 200, 150, 40);

        solarSystem = new JButton("Solar-System simulation");
        solarSystem.setBounds(100, 300, 200, 50);
        solarSystem.addActionListener(this);

        definissez = new JButton("Définisser un satellite");
        definissez.setBounds(325, 300, 200, 50);
        definissez.addActionListener(this);

        start = new JButton("Start");
        start.setBounds(545, 300, 105, 50);
        start.addActionListener(this);


        Help = new JLabel("?about & how to use");
        Font font4 = new Font("Bradley Hand ITC", Font.PLAIN, 16);
        Help.setFont(font4);
        Help.setSize(600, 50);
        Help.setLocation(600, 400);
        Help.setForeground(new Color(136, 200, 255));

        panneauGlobal = new JPanel();
        panneauGlobal.setBounds(0, 0, 1000, 500);
        panneauGlobal.setLayout(null); // positionnement absolut
        panneauGlobal.setBackground(Color.BLACK);
        panneauGlobal.add(plCentral);
        panneauGlobal.add(SelectCtr);
        panneauGlobal.add(plAutour);
        panneauGlobal.add(SelectAtr);
        panneauGlobal.add(solarSystem);
        panneauGlobal.add(definissez);
        panneauGlobal.add(start);

        this.add(panneauGlobal);

        this.setVisible(true);

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == start) {
            if(SelectCtr.getSelectedItem().equals("non-selected")||SelectAtr.getSelectedItem().equals("non-selected")){
                JOptionPane.showMessageDialog(this, "Selectionez-vous un astre central et un satellite ou le déffiniser!");
            }
            for (AstreCentrale c : astresCtr) {
                for (AstreAutour a : astresAtr) {
                    // Si le soleil est sélecté comme l'astre central, La lune ne pourra pas être sélectée comme l'astre autour.
                    if (c.name == SelectCtr.getSelectedItem() && SelectCtr.getSelectedItem() == "soleil"
                            && a.name == SelectAtr.getSelectedItem() && a.name != "lune") {
                        fenetreSimu = new SimulationObt(c, a);
                        fenetreSimu.setVisible(true);
                        fenetreSimu.lancement();
                    }
                    // Si la terre est sélectée comme l'astre central, les astres hor de la lune ne pourra pas être sélectée comme l'astre autour.
                    if (c.name == SelectCtr.getSelectedItem() && SelectCtr.getSelectedItem() == "terre"
                            && a.name == SelectAtr.getSelectedItem() && a.name == "lune") {
                        fenetreSimu = new SimulationObt(c, a);
                        fenetreSimu.setVisible(true);
                        fenetreSimu.lancement();
                    }
                }

            }

        }
        if (e.getSource() == solarSystem) {
            windowSolar = new SimSysSolar(astresCtr.get(0), astresAtr);
            //windowSolar.setVisible(true);
            windowSolar.lancement();
        }
        if(e.getSource() == definissez){
            SelectAtr.setSelectedItem("non-selected");
                for (AstreCentrale c : astresCtr) {
                        if (c.name == SelectCtr.getSelectedItem()){
                            FenetreDefinition fd = new FenetreDefinition(c);

                    }
                    }
                if(SelectCtr.getSelectedItem().equals("non-selected")){
                        JOptionPane.showMessageDialog(this, "Selectionez-vous un astre central!");
                    }
            
        }

    }

}
