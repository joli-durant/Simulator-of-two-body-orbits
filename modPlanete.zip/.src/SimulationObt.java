import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.Timer;
import java.awt.geom.Ellipse2D;//utiliser ellipse2D avec 'double' pour présicer la simulation
import java.awt.image.BufferedImage;

public class SimulationObt extends JFrame implements ActionListener {

        public AstreCentrale astreCentral;
        public AstreAutour astreAutour;
        public int delay = 20;
        public int DELTA_T = 2000;
        private Timer monChrono;
        private int temps;
        Graphics buffer; // Pour la fluidite des animations
        Dimension dim; // Dimension de la fenetre de l'Applet
        BufferedImage ArrierePlan; // L'arriere plan sur lequel on dessine

        private JPanel Options;
        private JPanel Canvas;
        private JButton Pause;
        private JButton Continue;
        private JLabel lbrot;
        private JSlider Speed_rot;//Modifier delay
        private JLabel lbpre;
        private JSlider Precision;//Modifier DELTA_T

        public SimulationObt(AstreCentrale c, AstreAutour a) {

                this.astreCentral = c;
                this.astreAutour = a;
                this.setTitle("Simulation Orbitale");
                this.setSize(1000, 850);
                this.setLocation(800, 0);
                this.setLayout(null);
                this.setResizable(false);
                this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                dim = this.getSize(); // récupère la taille réelle de la fenêtre
                // Creation de l'arriere plan sur laquelle on va dessiner
                ArrierePlan = new BufferedImage(dim.width, dim.height-80, BufferedImage.TYPE_INT_RGB);
                buffer = ArrierePlan.getGraphics();
                // Récupération du buffer graphique sera associé à l‘ArrierePlan

                monChrono = new Timer(delay, this);
                temps = 0;

        //Ajouter les comportements
        Continue = new JButton("Continue");
        Continue.setBounds(25, 0, 100, 35);
        Continue.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent c) {
                lancement();
            }
        });

        Pause = new JButton("Pause");
        Pause.setBounds(200, 0, 100, 35);
        Pause.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent p) {
                stop();
            }
        });


        lbrot = new JLabel("Vitesse de rotation: ");
        lbrot.setBounds(385,0,150,50);
        Speed_rot = new JSlider(1,100);
        Speed_rot.setBounds(500, 0, 100, 50);
        Speed_rot.setBackground(Color.BLACK);

        lbpre = new JLabel("Présition de la simulation: ");
        lbpre.setBounds(650,0,175,50);
        Precision = new JSlider(1,100);
        Precision.setBounds(800, 0, 100, 50);
        Precision.setBackground(Color.BLACK);


        Canvas = new JPanel();
        Canvas.setBounds(0, 0, dim.width, dim.height-80);
        Canvas.setLayout(null);
        Canvas.setBackground(Color.black);
        

        Options = new JPanel();
        Options.setBounds(0, dim.height-80, dim.width, 50);
        Options.setLayout(null); // positionnement absolut
        Options.setBackground(Color.BLACK);
        Options.add(Pause);

        Options.add(Continue);
        Options.add(lbrot);
        Options.add(Speed_rot);
        Options.add(lbpre);
        Options.add(Precision);

        this.add(Canvas);
        this.add(Options);

        this.setVisible(true);
        }

        @Override
        public void actionPerformed(ActionEvent e) {
                //Controlement de la vitesse et la précision par JSlider
                this.delay = 2000/Speed_rot.getValue();
                monChrono.setDelay(delay);
                this.DELTA_T = 100000/Precision.getValue();
                // améliorer la qualité d'image
                ((Graphics2D) buffer).setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                RenderingHints.VALUE_ANTIALIAS_ON);
                ((Graphics2D) buffer).setRenderingHint(RenderingHints.KEY_RENDERING,
                                RenderingHints.VALUE_RENDER_QUALITY);
                ((Graphics2D) buffer).setRenderingHint(RenderingHints.KEY_STROKE_CONTROL,
                                RenderingHints.VALUE_STROKE_PURE);
                ((Graphics2D) buffer).setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                                RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

                buffer.setColor(Color.black);
                buffer.fillRect(0, 0, this.getWidth(), this.getHeight());
                // afficher les parametres
                buffer.setColor(Color.white);
                buffer.drawString("Frame rate: " + (short) (1 / (delay * 0.001)), 875, 100);
                buffer.drawString(
                                "T = " + temps + " seconds, " + (double) temps / 86400 + " days, "
                                                + (double) temps / (86400 * 365)
                                                + " years",
                                50, 100);
                buffer.drawString("Theta = " + String.valueOf(this.astreAutour.theta * (180 / Math.PI)) + " degrees, "
                                + String.valueOf(this.astreAutour.theta / Math.PI) + "π rad", 50, 150);
                buffer.drawString("Current coordinates(AU): X = " + this.astreAutour.realPosition.x / astreAutour.UA
                                + ", Y = "
                                + this.astreAutour.realPosition.y / astreAutour.UA, 50, 200);
                buffer.drawString(
                                "Current distance: " + Math.sqrt(
                                                (Math.pow(this.astreAutour.realPosition.x, 2)
                                                                + Math.pow(this.astreAutour.realPosition.y, 2)))
                                                + " KM, " + Math.sqrt(
                                                                (Math.pow(this.astreAutour.realPosition.x, 2)
                                                                                + Math.pow(this.astreAutour.realPosition.y,
                                                                                                2)))
                                                                / astreAutour.UA
                                                + " AU",
                                50, 250);
                // dessiner astre central
                Ellipse2D.Double c = new Ellipse2D.Double(astreCentral.windowPosition.ctrToLEFTTOP().x,
                                astreCentral.windowPosition.ctrToLEFTTOP().y, astreCentral.rayons, astreCentral.rayons);
                buffer.setColor(astreCentral.colorAstre);
                ((Graphics2D) buffer).fill(c);

                // dessiner astre autour
                Ellipse2D.Double a = new Ellipse2D.Double(astreAutour.windowPosition.ctrToLEFTTOP().x,
                                astreAutour.windowPosition.ctrToLEFTTOP().y, astreAutour.rayons, astreAutour.rayons);
                buffer.setColor(astreAutour.colorAstre);
                ((Graphics2D) buffer).fill(a);

                temps += DELTA_T;
                astreAutour.moveAstre(DELTA_T);
    
            repaint();
        }

        public void paint(Graphics g) {
                super.paint(g);
                g.drawImage(ArrierePlan, 0, 0, Canvas);

        }

        public void lancement() {
                monChrono.start();
        }

        public void stop() {
                monChrono.stop();
        }

}
