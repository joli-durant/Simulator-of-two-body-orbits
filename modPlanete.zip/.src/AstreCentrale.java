import java.awt.Color;

public class AstreCentrale extends Astre {

    public AstreCentrale(Color colorAstre, int rayons, double masse, String name) {
        super(colorAstre, rayons, masse, name);
        // origine millieu de la fênetre
        this.realPosition = new Point(0, 0);
        this.windowPosition = new Point(0, 0);
    }

}
