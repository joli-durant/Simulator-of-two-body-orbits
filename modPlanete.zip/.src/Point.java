public class Point {
    // point origine par défaut: millieu de la fênetre
    public double x;
    public double y;

    public Point(double x, double y) {
        // On veut que point origine soit situé au centre
        this.x = x;
        this.y = y;// un peu changement de base à réflichir
    }

    public Point ctrToLEFTTOP() {// la point origine soit au LEFTTOP de la fênetre
        Point ctrLT = new Point(this.x + 500, 425 - this.y);
        return ctrLT;
    }
}
