import java.awt.Color;

public class AstreAutour extends Astre {
        public double distance;// Distance entre l'astre et l'astre cenrale
                               // en UA

        public AstreCentrale centre;

        public Point forceAttract;// comme les vecteurs
        public Point vitesseRot;
        public double initVitesse;
        public double theta;
        public double indice;

        public AstreAutour(Color colorAstre, AstreCentrale centre, int rayons, double masse, String name,
                        double distance,
                        double initVitesse) {
                super(colorAstre, rayons, masse, name);
                this.distance = distance;
                this.realPosition = new Point(distance * UA, 0);
                this.windowPosition = new Point(
                                Math.pow(this.realPosition.x / UA, 0.5) * 100 + centre.rayons * Math.cos(theta),
                                Math.pow(this.realPosition.y / UA, 0.5) * 100 + centre.rayons * Math.sin(theta));
                this.initVitesse = initVitesse;
                this.vitesseRot = new Point(0, initVitesse);
                this.centre = centre;

                indice = getIndice(300);
        }

        public void moveAstre(double dt) {// cette méthode est utilisé dans ActionListener
                double Fx = -G * this.masse * this.centre.masse * realPosition.x
                                / Math.pow(Math.pow(realPosition.x, 2) + Math.pow(realPosition.y, 2), 1.5);
                double Fy = -G * this.masse * this.centre.masse * realPosition.y
                                / Math.pow(Math.pow(realPosition.x, 2) + Math.pow(realPosition.y, 2), 1.5);
                this.forceAttract = new Point(Fx, Fy);

                vitesseRot.x = vitesseRot.x + dt * Fx / (this.masse);
                vitesseRot.y = vitesseRot.y + dt * Fy / (this.masse);

                this.realPosition.x += dt * vitesseRot.x;
                this.realPosition.y += dt * vitesseRot.y;

                // codes Matlab pour faire des référence:
                // modélisation de l'orbite de la lune et la terre
                // F(q,c)=-G*mL*mT*R(q,c)/(R(q,1)^2+R(q,2)^2)^(3/2);
                // V(q+1,:)=V(q,:)+dt*F(q,:)/mL;
                // R(q+1,:)=R(q,:)+dt*V(q+1,:);

                // Balance de dégonflage
                if (centre.name == "soleil") {
                        if (this.realPosition.x >= 0 && this.realPosition.y >= 0) {
                                this.theta = Math.atan(realPosition.y / realPosition.x);
                                this.windowPosition.x = Math.sqrt(Math.abs(this.realPosition.x / UA)) * 75
                                                + centre.rayons * Math.cos(theta);
                                this.windowPosition.y = Math.sqrt(Math.abs(this.realPosition.y / UA)) * 75
                                                + centre.rayons * Math.sin(theta);
                        }
                        if (this.realPosition.x <= 0 && this.realPosition.y >= 0) {
                                this.theta = Math.PI + Math.atan(realPosition.y / realPosition.x);
                                this.windowPosition.x = -Math.sqrt(Math.abs(this.realPosition.x / UA)) * 75
                                                + centre.rayons * Math.cos(theta);
                                this.windowPosition.y = Math.sqrt(Math.abs(this.realPosition.y / UA)) * 75
                                                + centre.rayons * Math.sin(theta);
                        }
                        if (this.realPosition.x <= 0 && this.realPosition.y <= 0) {
                                this.theta = Math.PI + Math.atan(realPosition.y / realPosition.x);
                                this.windowPosition.x = -Math.sqrt(Math.abs(this.realPosition.x / UA)) * 75
                                                + centre.rayons * Math.cos(theta);
                                this.windowPosition.y = -Math.sqrt(Math.abs(this.realPosition.y / UA)) * 75
                                                + centre.rayons * Math.sin(theta);
                        }
                        if (this.realPosition.x >= 0 && this.realPosition.y <= 0) {
                                this.theta = 2 * Math.PI + Math.atan(realPosition.y / realPosition.x);
                                this.windowPosition.x = Math.sqrt(Math.abs(this.realPosition.x / UA)) * 75
                                                + centre.rayons * Math.cos(theta);
                                this.windowPosition.y = -Math.sqrt(Math.abs(this.realPosition.y / UA)) * 75
                                                + centre.rayons * Math.sin(theta);
                        }
                }else{
                        if (this.realPosition.x >= 0 && this.realPosition.y >= 0) {
                                this.theta = Math.atan(realPosition.y / realPosition.x);
                                this.windowPosition.x = this.realPosition.x / UA * indice;
                                this.windowPosition.y = this.realPosition.y / UA * indice;

                        }
                        if (this.realPosition.x <= 0) {
                                this.theta = Math.PI + Math.atan(realPosition.y / realPosition.x);
                                this.windowPosition.x = this.realPosition.x / UA * indice;
                                this.windowPosition.y = this.realPosition.y / UA * indice;
                        }
                        if (this.realPosition.x >= 0 && this.realPosition.y <= 0) {
                                this.theta = 2 * Math.PI + Math.atan(realPosition.y / realPosition.x);
                                this.windowPosition.x = this.realPosition.x / UA * indice;
                                this.windowPosition.y = this.realPosition.y / UA * indice;

                        }

                }
        }

        public double getIndice(int limWinLength){//pour avoir une indice afin balancer le dégonflage
                double indice = 100;
                while(distance*indice<limWinLength){
                        indice+=50;
                }
                return indice;
        }
}
