import java.awt.*;

public abstract class Astre {
    // variables fixes
    public final double G = 6.67e-11;
    public final static double UA = (double) 149597870.691e3;

    public Color colorAstre;
    public int rayons;
    public double masse;
    public String name;
    public Point windowPosition;
    public Point realPosition;

    // constructeur
    public Astre(Color colorAstre, int rayons, double masse, String name) {
        this.colorAstre = colorAstre;
        this.rayons = rayons;
        this.masse = masse;
        this.name = name;
    }

}
