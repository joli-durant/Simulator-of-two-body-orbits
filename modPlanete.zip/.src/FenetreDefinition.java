import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;


public class FenetreDefinition extends JFrame implements ActionListener{

    JPanel panneauGlobal;
    JComboBox SelectColor;
    JLabel lbColor;
    JTextField EnterMasse;
    JLabel lbMasse;
    JTextField EnterDistance;
    JLabel lbDistance;
    JTextField EnterVelocity;
    JLabel lbV;
    JButton Confirm;
    String colorStr[];
    ArrayList<Color> colorToChoose;
    SimulationObt fenetreSimu;


    private String nom = "MonAstreAutour";
    private AstreCentrale ctr;

    public AstreAutour astreCree;

    public FenetreDefinition(AstreCentrale ctr) {
        this.ctr = ctr;

        this.setTitle("DEFFINISEZ VOTRE ASTRE AUTOUR:");
        this.setSize(800, 500);
        this.setLocation(0, 500);
        //this.setForeground(Color.BLACK);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        lbColor = new JLabel("Color: ");
        lbColor.setBounds(125, 100, 100, 50);
        Font font1 = new Font("Arial Black", Font.PLAIN, 17);
        lbColor.setFont(font1);
        lbColor.setForeground(Color.WHITE);
        
        colorToChoose = new ArrayList<Color>();
        colorToChoose.add(Color.RED);
        colorToChoose.add(Color.GREEN);
        colorToChoose.add(Color.BLUE);
        colorToChoose.add(Color.YELLOW);
        colorToChoose.add(Color.ORANGE);
        colorToChoose.add(Color.WHITE);
        colorToChoose.add(Color.MAGENTA);
        colorToChoose.add(Color.pink);
        colorToChoose.add(Color.CYAN);
        colorStr = new String[] {"red", "green", "blue", "yellow","orange","white","magenta","pink","cyan"};
        SelectColor = new JComboBox(colorStr);
        SelectColor.setBounds(200, 110, 100, 30);

        lbMasse = new JLabel("Masse(kg): ");
        lbMasse.setBounds(125, 200, 120, 50);
        lbMasse.setFont(font1);
        lbMasse.setForeground(Color.WHITE);
        EnterMasse = new JTextField();
        EnterMasse.setBounds(250, 210, 100, 30);

        lbDistance = new JLabel("Distance(AU): ");
        lbDistance.setBounds(425, 100, 140, 50);
        lbDistance.setFont(font1);
        lbDistance.setForeground(Color.WHITE);
        EnterDistance = new JTextField();
        EnterDistance.setBounds(575, 110, 100, 30);

        lbV = new JLabel("Vitesse(m/s): ");
        lbV.setBounds(425, 200, 140, 50);
        lbV.setFont(font1);
        lbV.setForeground(Color.WHITE);
        EnterVelocity = new JTextField();
        EnterVelocity.setBounds(575, 210, 100, 30);

        Confirm = new JButton("Confirm");
        Confirm.setBounds(310,275,100,50);
        Confirm.addActionListener(this);

        panneauGlobal = new JPanel();
        panneauGlobal.setBounds(0, 0, 800, 500);
        panneauGlobal.setLayout(null); // positionnement absolut
        panneauGlobal.setBackground(Color.BLACK);
        panneauGlobal.add(lbColor);
        panneauGlobal.add(SelectColor);
        panneauGlobal.add(lbMasse);
        panneauGlobal.add(EnterMasse);
        panneauGlobal.add(lbDistance);
        panneauGlobal.add(EnterDistance);
        panneauGlobal.add(lbV);
        panneauGlobal.add(EnterVelocity);
        panneauGlobal.add(Confirm);

        this.add(panneauGlobal);
        this.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        if(e.getSource()==Confirm) {
            double masse = Double.parseDouble(EnterMasse.getText());
            double distance = Double.parseDouble(EnterDistance.getText());
            double vitesse = Double.parseDouble(EnterVelocity.getText());
            Color couleurAstre = this.getSelectedColor();
            astreCree = new AstreAutour(couleurAstre, ctr, (int)ctr.rayons/2, masse, nom, distance, vitesse);
            SimulationObt fenetreSimu = new SimulationObt(ctr, astreCree);
            fenetreSimu.setVisible(true);
            fenetreSimu.lancement();
    
        }
    }

    public AstreAutour getAstreAtr(){
        return this.astreCree;
    }

    public Color getSelectedColor(){
        int i = 0;
        while(colorStr[i].equals(SelectColor.getSelectedItem())==false){
            i++;
        }
        return colorToChoose.get(i);
    }
    
}
